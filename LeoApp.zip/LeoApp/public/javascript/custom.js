(function(){
	$(document).ready(function(){

		$(".paginations").customPaginate({

			 itemsToPaginate:".post",
			 activeClass:"active"

		});
	});
}())

